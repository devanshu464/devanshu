# -*- coding: utf-8 -*-
"""
Created on Tue Oct 13 23:07:23 2020

@author: HP
"""
def function(str, k): 
  
    for i in range(len(str)): 
        if i %k == 0: 
            sub = str[i:i+k] 
            lst = [] 
            for j in sub: 
                lst.append(j) 
            print(''.join(lst))
    
            

string = "If man was meant to stay on the ground, God would have given us roots"

i = 0
newStr = ""
while(i <len(string)):
    data = string[i]
    specialchar = ord(data)
    if(data == " "):
        i = i + 1
    elif(specialchar >= 32 and specialchar <= 47 or specialchar >= 58 and 
         specialchar <= 64 or specialchar >= 91 and specialchar <= 96
         or specialchar >= 123 and specialchar <= 126):
        i = i + 1
    else:
        newStr = newStr + data
        i = i + 1
print(newStr)
function(newStr, 8)



