# -*- coding: utf-8 -*-
"""
Created on Tue Oct 13 18:46:54 2020

@author: HP
"""

def reverseString(str):
    if(len(str) == 0):
        return str
    else:
        return reverseString(str[1:] )+ str[0]
    
    
string = "Devanshu"
print(reverseString(string))
print()
