def procedure(str1,target):
    words=str1.split(" ")
    sol=[]
    for i in range(len(words)):
        if words[i]==target:
            sol.append(i)
    if len(sol)==0:
        return False
    return sol
str1="we dont need no education we dont need no thought control no we dont"
print(procedure(str1,"dont"))