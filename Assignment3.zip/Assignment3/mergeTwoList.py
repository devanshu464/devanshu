# -*- coding: utf-8 -*-
"""
Created on Tue Oct 13 18:57:50 2020

@author: HP
"""




def sorting(list1):
    for i in range(len(list1)):
        for j in range(i + 1, len(list1)):
        
            if list1[i]  > list1[j]:
                temp = list1[i]
                list1[i] = list1[j]
                list1[j] = temp
            else:
                    pass
    return list1              

mylist1 = [10,20,12,13,14]
mylist2 = [33,11,22,10]
sorted1 = sorting(mylist1)
sorted2 = sorting(mylist2)
print(sorted1)
print(sorted2)
merge = sorted1 + sorted2
print(merge)


