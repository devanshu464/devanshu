
dict1={'1':10,'2':20,'3':30,'4':40,'5':10,'6':10}
ele={}
for key,value in dict1.items():
    if value not in ele:
        ele[value]=0
    else:
        ele[value]+=1
print(max(ele,key=ele.get))