# -*- coding: utf-8 -*-
"""
Created on Mon Oct 12 16:12:45 2020

@author: HP
"""
list1 = list(range(1,100))
#print(list1)

newlist1 = [num for num in list1 if num % 2 == 1]
print(newlist1)
