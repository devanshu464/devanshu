# -*- coding: utf-8 -*-
"""
Created on Tue Oct 13 19:46:43 2020

@author: HP
"""

def pay_bills(paid, cost):
    returnamount = paid - cost
    change = {}
    
    Numberofchnageof_20 = returnamount // 20
    change['$20'] = Numberofchnageof_20
    restamountinchange = returnamount % 20
    
    Numberofchnageof_10 =  restamountinchange // 10
    change['$10'] = Numberofchnageof_10
    restamountinchange =  restamountinchange % 10
    
    
    Numberofchnageof_5 =  restamountinchange // 5
    change['$5'] = Numberofchnageof_5
    restamountinchange =  restamountinchange % 5
    
    Numberofchnageof_2 =  restamountinchange // 2
    change['$2'] = Numberofchnageof_2
    restamountinchange =  restamountinchange % 2
    
    Numberofchnageof_1 =  restamountinchange // 1
    change['$1'] = Numberofchnageof_1
    restamountinchange =  restamountinchange % 1
    
    for k, v in change.items():
        if v != 0:
            print('Need', v, 'bills of', k)
            
pay_bills(200,100)

    
    