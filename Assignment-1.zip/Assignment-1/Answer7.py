# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 00:12:06 2020

@author: kumardevanshu464@gmail.com
"""
#factorial program
print("Enter the number")
n = int(input())
num = 1
for i in range(n, 1, -1):
    num = num* i
print(num)