# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 00:06:59 2020

@author: kumardevanshu464@gmail.com
"""
print("Enter the number")
num = int(input())
print()

for i in range(1, 11):
    newnum = num * i
    print(newnum)
    print("\n")
    