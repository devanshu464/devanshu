# -*- coding: utf-8 -*-
"""
Created on Sat Sep 26 23:38:13 2020

@author:kumardevanshu464@gmail.com
"""

print("Enter the input")
n = int(input())

for i in range(n):
    for j in range(i+1):
        
        print("*", end = " ")
    print("\r")
    
for i in range(n, 0, -1):
    for j in range(0, i - 1):
        print("*", end=' ')
    print("\r")
    
