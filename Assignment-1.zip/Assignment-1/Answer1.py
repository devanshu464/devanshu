# -*- coding: utf-8 -*-
"""
Created on Fri Sep 25 23:38:58 2020

@author: kumardevanshu464@gmail.com
"""

print("enter the first string")
s1 = input()

print("enter the second string")
s2 = input()

i = 0
j = len(s2) - 1
newstr = ""

#when both the string is of equal length

if(len(s1) == len(s2)):
    
    for i in range(len(s1)):
    #for j in range(len(s2)-1, -1, -1):
        
        newstr = s1[i] + s2[j]
        j = j - 1
        print(newstr, end = "")

#when length of first string is greater than the second string
elif(len(s1) > len(s2)):
    if(j != 0):
        
        for i in range(len(s2)):
            newstr = s1[i] + s2[j]
            j = j - 1
            print(newstr,end = "")
    k = len(s2)
    while(k <= len(s1)):
        
        resstr = ""
    
        resstr = resstr + s1[k]
        print(resstr)
        k = k + 1

#when length of second string is greater than the first string
else:
    if(i != len(s1)):
        for i in range(len(s1)):
            newstr = s1[i] + s2[j]
            i = i +1
            print(newstr,end = "")
    k = len(s1)
    while(k <= len(s2)):
        
        resstr = ""
    
        resstr = resstr + s1[k]
        print(resstr)
        k = k + 1
        
    