# -*- coding: utf-8 -*-
"""
Created on Sat Sep 26 22:18:43 2020

@author: kumardevanshu464@gmail.com
"""

print("Enter the string of odd length")
String = input()

if(len(String) % 2 == 0):
    print("Please enter a valid string of odd length")
    
def middleString(String):
    #finding the middle character of the string
    middleChar = int(len(String)/2)
    #finding the three middle character
    return String[middleChar-1 : middleChar+2]

print(middleString(String))
    