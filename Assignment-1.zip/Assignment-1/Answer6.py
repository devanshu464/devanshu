# -*- coding: utf-8 -*-
"""
Created on Fri Sep 25 22:43:27 2020

@author: kumardevanshu464@gmail.com
"""
#Function to reverse a list

def reverseList(list1):
    newlist = []
    for i in range(len(list1)-1, -1, -1):
        newlist.append(list1[i])
    return newlist

# Driver code

list1 = [10, 20, 30, 40, 50]
print(reverseList(list1))