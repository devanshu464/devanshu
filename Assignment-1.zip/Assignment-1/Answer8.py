# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 00:17:08 2020

@author: kumardevanshu464@gmail.com
"""
# program to Accept a list of 5 float numbers as an input from the user
List = []
i = 0
while(i <= 4):
    print("Enter the floating point elements")
    ele = float(input())
    List.insert(i,ele)
    i = i + 1
    
print()
print(List)