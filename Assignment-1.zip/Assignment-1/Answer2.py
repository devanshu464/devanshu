# -*- coding: utf-8 -*-
"""
Created on Sat Sep 26 19:28:15 2020

@author: kumardevanshu464@gmail.com
"""

str1 = "Welcome to USA. usa awesome, isn't it?"
str2 = "usa"


i = 0
newstr = ""
while(i < len(str1)):
    data = str1[i]
    asciivalue = ord(data)
    if(asciivalue >= 65 and asciivalue <= 90):
        newasciivalue = asciivalue + 32
        newChar = chr(newasciivalue)
        newstr = newstr + newChar
    else:
        newstr = newstr + data
    i = i + 1
#print(newstr)

count = newstr.count(str2)
print("The USA count is:", count)

        