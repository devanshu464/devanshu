# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 01:31:26 2020

@author: kumardevanshu464@gmail.com
"""

import numpy as np
from numpy import asarray
import matplotlib.image as mpimg
img = mpimg.imread('wild.png')
data = asarray(img)
print (data.shape)

print()

print(data)

print(type(data))


img_r = np.reshape(img, (256, 1396))

data = asarray(img_r)
print (img_r.shape)
print(data)
print(type(data))

