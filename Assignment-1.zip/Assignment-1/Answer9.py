# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 13:13:44 2020

@author: kumardevanshu464@gmail.com
"""

import random
import string


for i in range(2):
    password = random.choice(string.ascii_uppercase)
    password = password+ random.choice( string.punctuation)
    
#print(password)

for  i in range(5):
    password = password + random.choice(string.digits)
    
print(password)