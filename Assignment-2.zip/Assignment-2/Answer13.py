# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 01:19:02 2020

@author: HP
"""

class Person:
    def getName(self):
        name = input("enter the name")
        self.name = name
        
    def printName(self):
        print("Name", self.name)
        
per = Person()
per.getName()
per.printName()
        