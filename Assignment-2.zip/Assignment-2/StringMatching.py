# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 00:44:16 2020

@author: HP
"""
import string
import random
'''donot enter the repeated character'''
'''enter unique digit, special, lowercase and upercase'''
str1 = input("Enter the string\t")
resultantString = ''
i = 0

while( str1 != resultantString):
    
    randomString = string.digits + string.ascii_lowercase + string.ascii_uppercase + string.punctuation
#print(randomString)

    resultantString = ''.join(random.sample(randomString,len(str1)))
    print(resultantString, end = "")
    print()
    i = i + 1
    

    
    