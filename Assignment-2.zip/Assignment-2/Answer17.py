# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 02:33:51 2020

@author: HP
"""

val = input("Enter the value of a")

n1 = (val * 1)
n2 = ( val * 2) 
n3 = (val * 3)
n4 = ( val * 4)
print(int(n1)+ int(n2) + int(n3) +int( n4))
