# -*- coding: utf-8 -*-
"""
Created on Mon Oct  5 00:12:25 2020

@author: HP
"""

string1 = input("Enter the string consisting of special symbol, digit, upper case and lowercase letter\n")
print()

i = 0

countOfDigit = 0

countOfUppercaseLetter = 0

countOfLowercaseLetter = 0

countOfSpecialSymbol = 0

while(i < len(string1)):
    data = string1[i]
    asciivalueOfdata = ord(data)
    if(asciivalueOfdata >= 48 and asciivalueOfdata <= 57):
        countOfDigit = countOfDigit + 1
        i = i + 1
    elif(asciivalueOfdata >= 65 and asciivalueOfdata <= 90):
        countOfUppercaseLetter = countOfUppercaseLetter + 1
        i = i + 1
    elif(asciivalueOfdata >= 97 and asciivalueOfdata <= 122):
        countOfLowercaseLetter = countOfLowercaseLetter + 1
        i = i + 1
    elif((asciivalueOfdata >= 33 and asciivalueOfdata <= 47) or (asciivalueOfdata >= 58 and asciivalueOfdata <= 64) or (asciivalueOfdata >= 91 and asciivalueOfdata <= 96) or (asciivalueOfdata >= 123 and asciivalueOfdata <= 126) ):
        countOfSpecialSymbol = countOfSpecialSymbol + 1
        i = i + 1
    else:
        print("Kindly enter the valid string")
print("Count of digit = ", countOfDigit)
print()
print("count of upper case letter = ", countOfUppercaseLetter)
print()
print("count of Lower Case Letter = ", countOfLowercaseLetter)
print()
print("count of Special symbol = ", countOfSpecialSymbol)
        
print()
    
