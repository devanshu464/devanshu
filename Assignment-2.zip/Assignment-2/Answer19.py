# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 15:18:16 2020

@author: HP
"""
import math
X = Y =0
step = 0
newStep = 0
newDirection = ""
distance = 0
while  True:
    directionStep = input("enter the input")
    direction = directionStep.split(" ")
    newDirection = direction[0]
    newStep = direction[1]
    
    if(newDirection == "UP"):
        Y = Y + int(newStep)
        #print(Y)
        
    elif(newDirection == "DOWN"):
        Y = Y - int(newStep)
        #print(Y)
        
    elif(newDirection == "RIGHT"):
        X = X + int(newStep)
        #print(X)
        
    elif(newDirection == "LEFT"):
        X = X - int(newStep)
        #print(X)
    distance = int(math.sqrt(X**2 + Y ** 2))
    print("DISTANCE:\t",distance)