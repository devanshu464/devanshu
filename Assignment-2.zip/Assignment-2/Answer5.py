# -*- coding: utf-8 -*-
"""
Created on Mon Oct  5 21:05:39 2020

@author: HP
"""

class Vehicle:

    def __init__(self, name, mileage, capacity):

        self.name = name

        self.mileage = mileage

        self.capacity = capacity

    def fare(self):

        return self.capacity * 100

class Bus(Vehicle):
    def fare(self,capacity = 50):
        fares = self.capacity * 100
        maintenanceCharge = 0.1 * fares
        return fares + maintenanceCharge
    
School_bus = Bus("volvo",50,50)
print("Total Bus fare is:", School_bus.fare())
        