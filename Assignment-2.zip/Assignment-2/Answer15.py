# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 01:25:07 2020

@author: HP
"""

class String:
    
    def getString(self):
        self.string = input("Enter the string\t")
        
    def printString(self):
        print(self.string.upper())
        
Str = String()
Str.getString()
Str.printString()