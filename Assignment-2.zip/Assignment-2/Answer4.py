# -*- coding: utf-8 -*-
"""
Created on Mon Oct  5 01:01:30 2020

@author: HP
"""

class Vehicle:
    def __init__(self, name, max_speed, mileage):

        self.name = name

        self.max_speed = max_speed

        self.mileage = mileage
        
    def seating_capacity(self, capacity):
        self.capacity = capacity
        print("The seating capacity of a {} is {} passengers".format(self.name,self.capacity))
    
class Bus(Vehicle):
    def seating_capacity(self, capacity = 50):
        self.capacity = capacity
        
        print("The seating capacity of a {} is {} passengers".format(self.name,self.capacity))
    
    
bus = Bus("Volvo",120, 10)
bus.seating_capacity()



    

        