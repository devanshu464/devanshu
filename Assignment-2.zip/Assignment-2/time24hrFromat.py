# -*- coding: utf-8 -*-
"""
Created on Wed Oct  7 23:23:32 2020

@author: HP
"""

hr = int(input("Enter hour\t"))

mins = int(input("enter mins\t"))

sec = int(input("Enter sec\t"))

AmPm = input("Enter AM or PM\t")

if hr > 23 or hr < 0:
    print("invalid entry for hour")
#break
    
elif( mins > 59 or mins < 0):
    print("invalid entry of minutes")
#break
    
elif( sec > 59 or sec < 0):
    print("invalid entry of seconds")
#break
    
else:
    pass
    
if AmPm == "AM":
    if hr == 12:
        hr = 00
        print(hr,end = ":")
        print(mins, end = ":")
        print(sec, end = ":")
        print("AM")
    else:
        print(hr,end = ":")
        print(mins, end = ":")
        print(sec, end = ":")
        print("AM")
        
    
if AmPm == "PM":
    if hr >= 12:
        hr = hr + 1
        print(hr,end = ":")
        print(mins, end = ":")
        print(sec, end = ":")
        print("PM")
        
    else:
        print(hr,end = ":")
        print(mins, end = ":")
        print(sec, end = ":")
        print("AM")
