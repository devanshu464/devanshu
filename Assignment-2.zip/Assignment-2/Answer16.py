# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 01:28:30 2020

@author: HP
"""

row = int(input("enter the value of row\t"))

col = int(input("enter the value of column\t"))
res = [[0 for col in range(col)] for row in range(row)]
for i in range(row):
    for j in range(col):
        
        res[i][j] = i * j
print(res)
        
        