# -*- coding: utf-8 -*-
"""
Created on Sun Oct  4 22:49:27 2020

@author: HP
"""

Num1 = int(input("Enter the first number\t"))

Num2 = int(input("Enter the second number"))

def product(num1, num2):
    Product = num1 * num2
    return Product
    

def sum(num1 ,num2):
    Sum = 0
    Sum = num1 + num2
    return Sum


if(product(Num1,Num2) > 1000):
    
    print("Here, product is greater than 1000, So a/c i am printing sum")
    print()
    print("Sum Of Two NUmbers is",sum(Num1, Num2))
    
else:
    print("Here the product of two numbers is less than 1000. so im printing product a/q")
    print()
    print("Product of two number is",product(Num1,Num2))
    
    
    