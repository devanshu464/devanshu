# -*- coding: utf-8 -*-
"""
Created on Wed Oct  7 19:41:15 2020

@author: HP
"""

number = int(input("enter the number\t"))
print("{:,}" .format(number))