# -*- coding: utf-8 -*-
"""
Created on Mon Oct  5 21:14:02 2020

@author: HP
"""

list1 = [50,30,40]
for i in range(0,3):
    data = list1[i]
    print(data, end = ",")