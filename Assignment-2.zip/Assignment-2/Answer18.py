# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 02:44:58 2020

@author: HP
"""
netamount = 0
while True:
    inp = input("Enter the input")
    newinp = inp.split(" ")
    #print(newinp)
    transactionType = newinp[0]
    amount = int(newinp[1])
    if (int(amount) < 0 ):
        print("invalid")
        break
    #print(transactionType)
    if(transactionType == "D"):
        netamount = netamount + amount 
        print(netamount)
    if(transactionType == "W"):
        if(netamount > amount):
            netamount = netamount - amount
            print(netamount)
            
        else:
           print("Insufficient funds")