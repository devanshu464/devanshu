# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 16:02:57 2020

@author: HP
"""
"""
|-|-|-|      |1|1|1|     |0|0|0|    |1|0|0|    |0|1|1|
|-|-|-|  or  |1|1|1| or  |0|0|0| or |0|1|0| or|1|0|1|
|-|-|-|      | 1|1|1|   |0|0|0|     |0|0|1|   |1|1|0|

working of tic tac toe game
if horizontal that is row value contain exactly three same value then 
any of the one player wins the game
if vertical that is column value contains exactly three same value then 
any one of the player  wins
diagonally filled elements should contain exactly same value then any one of the 
players will wins the game  

here we are taking two players and gameboard of 3X3 matrix.

"""


import random
row = 3

col = 3

newgameBoard = [[0 for i in range(row)] for j in range(col)]

#print(newgameBoard)

'''players turn'''
gameBoard = [random.choices(range(0,2), k = col) for _ in range(3)]
print(gameBoard)

# horizontal matches
if((gameBoard[0][0] == 1 and gameBoard[0][1] == 1 and gameBoard[0][2] == 1) or 
   (gameBoard[1][0] == 1 and gameBoard[1][1] == 1 and gameBoard[1][2] == 1)
   or (gameBoard[2][0] == 1 and gameBoard[2][1] ==1 and gameBoard[2][2] == 1)):
    print("loop1 \n players A wins")
    
elif((gameBoard[0][0] == 0 and gameBoard[0][1] == 0 and gameBoard[0][2] == 0) or 
   (gameBoard[1][0] == 0 and gameBoard[1][1] == 0 and gameBoard[1][2] == 0)
   or(gameBoard[2][1] == 0 and gameBoard[2][1] == 0 and gameBoard[2][2] == 0)):
    print("loop2 \n players B wins")
# vertical matches   
elif((gameBoard[0][0] == 0 and gameBoard[1][0] == 0 and gameBoard[1][2] == 0) or 
   (gameBoard[0][1] == 0 and gameBoard[1][1] == 0 and gameBoard[2][1] == 0)
   or(gameBoard[0][2] == 0 and gameBoard[1][2] == 0 and gameBoard[2][2] == 0)):
    print("loop3 \n players B wins")


elif((gameBoard[0][0] == 1 and gameBoard[1][0] == 1 and gameBoard[1][2] == 1) or 
   (gameBoard[0][1] == 1 and gameBoard[1][1] == 1 and gameBoard[2][1] == 1)
   or(gameBoard[0][2] == 1 and gameBoard[1][2] == 1 and gameBoard[2][2] == 1)):
    print("loop4 \n players A wins")
    
#diagonally matches
elif((gameBoard[0][0] == 1 and gameBoard[1][1] == 1 and gameBoard[2][2] == 1) or 
   (gameBoard[0][2] == 1 and gameBoard[1][1] == 1 and gameBoard[2][0] == 1)):
    print("loop5 \n players A wins")
elif((gameBoard[0][0] == 0 and gameBoard[1][1] == 0 and gameBoard[2][2] == 0) or 
   (gameBoard[0][2] == 0 and gameBoard[1][1] == 0 and gameBoard[2][0] == 0)):
    print("loop6 \n players B wins")
    
else:
    print("matches ties")