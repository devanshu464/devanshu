# -*- coding: utf-8 -*-
"""
Created on Wed Oct  7 21:21:02 2020

@author: HP
"""

string = input("Enter the string\t")


i = 0



countOfUppercaseLetter = 0

countOfLowercaseLetter = 0



while(i < len(string)):
    data = string[i]
    asciivalueOfdata = ord(data)
    if(asciivalueOfdata >= 65 and asciivalueOfdata <= 90):
        countOfUppercaseLetter = countOfUppercaseLetter + 1
        i = i + 1
    elif(asciivalueOfdata >= 97 and asciivalueOfdata <= 122):
        countOfLowercaseLetter = countOfLowercaseLetter + 1
        i = i + 1
    else:
        print("Kindly enter the valid string")

print("count of upper case letter = ", countOfUppercaseLetter)
print()
print("count of Lower Case Letter = ", countOfLowercaseLetter)
print()

