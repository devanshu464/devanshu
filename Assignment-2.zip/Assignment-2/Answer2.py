# -*- coding: utf-8 -*-
"""
Created on Sun Oct  4 23:19:42 2020

@author: HP
"""

num = int(input("Original number\t"))

rev = 0
temp = num

while num > 0:
    unitDigit = num % 10
    rev = rev * 10 + unitDigit
    num = num // 10
    
if temp == rev:
    
    print("The original and reverse number is the same")
    
else:
    print("The original and reverse number is not same")