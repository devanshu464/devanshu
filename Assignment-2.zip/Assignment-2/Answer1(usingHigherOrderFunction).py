# -*- coding: utf-8 -*-
"""
Created on Sun Oct  4 23:15:32 2020

@author: HP
"""

'''Answer1 using Higher order function'''

Num1 = int(input("Enter the first number\t"))

Num2 = int(input("Enter the second number"))

# getting product of two numbers using lambda function

product = lambda num1, num2 : num1 * num2

# getting sum of two numbers

sum = lambda num1, num2 : num1 + num2

if(product(Num1,Num2) > 1000):
    
    print("Here, product is greater than 1000, So a/c i am printing sum")
    print()
    print("Sum Of Two NUmbers is",sum(Num1, Num2))
    
else:
    print("Here the product of two numbers is less than 1000. so im printing product a/q")
    print()
    print("Product of two number is",product(Num1,Num2))